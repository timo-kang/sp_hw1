# sp_hw1
trivially copy file (tcp)

## tcp examples
tcp file1 file2


tcp file1 dir


tcp file1 dir/subdir/subsubdir/file2

## empty examples
input : sh empty.sh dir 

output : empty
