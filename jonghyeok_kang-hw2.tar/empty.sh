#! /bin/sh

find $1 -type d -empty > empty
